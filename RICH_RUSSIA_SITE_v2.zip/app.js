// Укажи реальные ссылки проекта ниже.
const PROJECT_LINKS = {
  launcher: "", // Например: https://example.com/rich-russia.apk
  telegram: ""  // Например: https://t.me/your_channel
};
const download = document.getElementById('downloadLink');
const community = document.getElementById('communityLink');
if (PROJECT_LINKS.launcher) download.href = PROJECT_LINKS.launcher;
else download.addEventListener('click', e => { e.preventDefault(); alert('Ссылка на лаунчер скоро появится!'); });
if (PROJECT_LINKS.telegram) community.href = PROJECT_LINKS.telegram;
else community.addEventListener('click', e => { e.preventDefault(); alert('Ссылка на Telegram скоро появится!'); });
document.getElementById('menuBtn').addEventListener('click', () => document.getElementById('nav').classList.toggle('open'));
document.querySelectorAll('#nav a').forEach(link => link.addEventListener('click', () => document.getElementById('nav').classList.remove('open')));
